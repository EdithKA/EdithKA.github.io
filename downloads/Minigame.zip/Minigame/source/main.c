#include <nds.h>
#include <stdio.h>
#include <time.h>

//Teselas
u8 cielo[64] =
{
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
  
};

u8 cesped[64] =
{
    3,2,2,2,2,3,2,2,
    3,2,2,2,3,3,2,2,
    2,3,3,2,2,2,3,3,
    2,2,3,2,2,2,2,3,
    2,2,2,2,3,2,2,2,
    3,3,2,3,3,2,2,2,
    2,3,2,2,2,3,3,2,
    2,2,2,2,2,3,2,2,
};

u8 suelo[64] =
{
	8,8,8,8,8,8,8,8,
	8,7,8,8,8,8,8,8,
    8,8,8,8,8,7,7,8,
    8,8,7,8,8,8,8,8,
    8,8,7,8,8,8,8,8,
    8,8,8,8,8,8,8,8,
    8,8,8,7,7,8,8,8,
    8,8,8,8,8,8,8,8,
  
};

u8 nube_pequeña[64] =
{
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
    0,0,1,1,1,0,0,0,
    0,1,1,1,1,1,1,0,
    0,0,1,0,0,1,0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,
  
};

u8 nube_grande[64] =
{
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
    0,0,1,1,1,1,0,0,
    1,1,1,1,1,1,1,0,
    1,1,1,1,1,1,1,0,
    0,1,1,1,1,1,0,0,
    0,0,0,1,1,1,0,0,
    0,0,0,0,0,0,0,0,
  
};


//casa
u8 casa_I1[64] =
{
	0,0,0,0,0,0,6,6,
    0,0,0,0,0,6,4,4,
    0,0,0,0,6,4,4,4,
    0,0,0,6,4,4,4,4,
    0,0,6,4,4,4,4,4,
    0,6,4,4,4,4,4,4,
    6,4,4,4,4,4,4,4,
    6,6,6,6,6,6,6,6,
};

u8 casa_D1[64] =
{
	6,6,0,0,0,0,0,0,
    4,4,6,6,6,6,0,0,
    4,4,4,6,5,6,0,0,
    4,4,4,4,6,6,0,0,
    4,4,4,4,4,6,0,0,
    4,4,4,4,4,4,6,0,
    4,4,4,4,4,4,4,6,
    6,6,6,6,6,6,6,6,
};

u8 casa_I2[64] =
{
    0,6,6,7,7,7,7,7,
    0,0,6,5,5,6,6,5,
    0,0,6,5,6,0,0,6,
    0,0,6,5,6,0,0,6,
    0,0,6,5,5,6,6,5,
    0,0,6,7,5,5,5,5,
    0,0,6,7,7,7,7,7,
    3,2,2,6,6,6,6,6,
};

u8 casa_D2[64] =
{
	7,7,7,7,7,7,6,6,
    5,5,5,5,5,5,6,0,
    5,5,5,5,5,5,6,0,
    5,5,6,6,5,5,6,0,
    5,6,8,8,6,5,6,0,
    5,6,8,8,6,5,6,0,
    7,6,8,8,6,5,6,0,
    6,6,6,6,6,6,2,3,
};

//serpiente
//1
u8 serpiente_I1[64] =
{
    3,2,2,2,2,3,2,2,
    3,2,2,2,6,6,6,6,
    2,3,3,6,4,4,4,4,
    2,2,3,6,4,4,4,4,
    2,2,6,4,6,4,4,4,
    3,3,6,4,6,4,4,4,
    2,3,6,4,4,4,4,4,
    2,2,2,6,4,4,4,4,
};

u8 serpiente_D1[64] =
{
    3,2,2,2,2,3,2,2,
    6,2,2,2,3,3,2,2,
    4,6,3,2,2,2,3,3,
    4,4,6,2,2,2,2,3,
    6,4,6,2,3,2,2,2,
    6,4,4,6,3,2,2,2,
    4,4,19,6,2,3,3,2,
    4,4,6,2,2,3,2,2,
};

u8 serpiente_I2[64] =
{
    8,7,7,8,6,6,6,6,
    8,8,6,6,4,4,6,4,
    8,6,4,4,4,6,4,4,
    6,4,4,6,4,4,4,4,
    6,4,4,4,6,6,6,6,
    6,4,4,4,4,4,4,4,
    8,6,4,4,4,4,4,4,
    7,8,6,6,6,6,6,6,
};

u8 serpiente_D2[64] =
{
    6,6,6,8,7,7,8,8,
    4,4,6,6,7,8,8,8,
    4,4,6,4,6,8,7,7,
    4,6,4,4,4,6,8,7,
    6,4,4,4,6,4,6,8,
    4,4,4,4,6,4,6,8,
    4,4,4,6,6,4,6,7,
    6,6,6,4,4,4,7,8,
};

//2
u8 serpiente2_I1[64] =
{
    3,2,2,2,2,3,2,2,
    3,2,2,2,3,3,2,2,
    2,3,3,2,2,2,3,6,
    2,2,3,2,2,2,2,6,
    2,2,2,2,3,2,6,4,
    3,3,2,3,3,2,6,4,
    2,3,2,2,2,3,6,4,
    2,2,2,2,2,3,2,6,
};

u8 serpiente2_D1[64] =
{
    3,2,2,2,2,3,2,2,
    6,6,6,6,6,3,2,2,
    4,4,4,4,4,6,3,3,
    4,4,4,4,4,4,6,3,
    6,4,4,4,6,4,6,2,
    6,4,4,4,6,4,4,6,
    4,4,4,4,4,4,4,6,
    4,4,4,4,4,4,6,2,
};

u8 serpiente2_I2[64] =
{
    8,7,7,8,6,6,7,7,
    8,8,6,6,4,4,6,6,
    8,6,4,4,4,6,4,4,
    6,4,4,6,4,4,4,4,
    6,4,4,4,6,6,6,6,
    6,4,4,4,4,4,4,4,
    8,6,4,4,4,4,4,4,
    7,8,6,6,6,6,6,6,
};

u8 serpiente2_D2[64] =
{
    6,6,6,6,6,6,8,8,
    4,4,4,6,7,8,8,8,
    4,4,6,4,6,8,7,7,
    4,6,4,4,4,6,8,7,
    6,4,4,4,6,4,6,8,
    4,4,4,4,6,4,6,8,
    4,4,4,6,6,4,6,7,
    6,6,6,4,4,4,7,8,
};

//Personaje
//frente
u8 p_frente1[64] =
{
    2,3,9,9,9,9,3,2,
    3,9,9,9,9,9,9,2,
    2,4,4,4,4,4,4,3,
    9,9,9,9,9,9,9,9,
    6,6,6,6,6,6,6,6,
    6,10,10,6,6,10,10,6,
    6,10,0,10,10,0,10,6,
    0,10,10,10,10,10,10,0,
};

u8 p_frente2[64] =
{
	10,4,4,10,10,4,4,10,
    10,4,4,4,4,4,4,10,
    10,4,4,4,4,4,4,10,
    10,4,4,4,4,4,4,10,
    10,11,11,11,11,11,11,10,
    8,11,11,7,8,11,11,8,
    8,11,11,8,8,11,11,8,
    8,9,9,8,8,9,9,7,
};

u8 p2_frente2[64] =
{
    8,8,9,9,9,9,8,8,
    8,9,9,9,9,9,9,8,
    8,4,4,4,4,4,4,8,
    9,9,9,9,9,9,9,9,
    6,6,6,6,6,6,6,6,
    6,10,10,6,6,10,10,6,
    6,10,0,10,10,0,10,6,
    0,10,10,10,10,10,10,0,
};

//derecha
u8 p_derecha1[64] =
{
	3,2,9,9,9,9,2,2,
	3,9,9,9,9,9,9,2,
    2,4,4,4,4,4,4,3,
    9,9,9,9,9,9,9,9,
    2,6,6,6,6,6,6,2,
    6,6,6,10,10,6,6,2,
    6,6,6,10,0,10,0,2,
    2,6,10,10,10,10,10,2,
  
};

u8 p_derecha2[64] =
{
	8,8,4,10,4,4,8,8,
	8,7,4,10,4,4,8,8,
    8,8,4,10,4,4,7,8,
    8,8,4,10,4,4,8,8,
    8,8,11,10,11,11,8,8,
    8,11,11,8,11,11,8,8,
    8,9,9,9,11,11,8,8,
    8,8,8,8,9,9,9,8,
  
};

u8 p2_derecha2[64] =
{
	8,8,4,10,4,4,8,8,
	8,7,4,10,4,4,8,8,
    8,8,4,10,4,4,7,8,
    8,8,4,10,4,4,8,8,
    8,8,11,10,11,11,8,8,
    8,8,11,11,8,11,11,8,
    8,8,11,11,7,9,9,9,
    8,8,9,9,9,8,8,8,
  
};

u8 p_derecha_suelo[64] =
{
	8,8,9,9,9,9,8,8,
	8,9,9,9,9,9,9,8,
    8,4,4,4,4,4,4,8,
    9,9,9,9,9,9,9,9,
    8,6,6,6,6,6,6,8,
    6,6,6,10,10,6,6,8,
    6,6,6,10,0,10,8,8,
    8,6,10,10,10,10,10,8,

};
//izquierda
u8 p_izquierda1[64] =
{
	3,2,9,9,9,9,2,2,
	3,9,9,9,9,9,9,2,
    2,4,4,4,4,4,4,3,
    9,9,9,9,9,9,9,9,
    2,6,6,6,6,6,6,2,
    3,6,6,10,10,6,6,6,
    2,3,10,0,10,6,6,6,
    2,10,10,10,10,10,6,2,
  
};

u8 p_izquierda2[64] =
{
	8,8,4,4,10,4,8,8,
	8,8,4,4,10,4,7,8,
    8,7,4,4,10,4,8,8,
    8,8,4,4,10,4,8,8,
    8,8,11,11,10,11,8,8,
    8,8,11,11,8,11,11,8,
    8,8,11,11,9,9,9,8,
    8,9,9,9,8,8,8,8,

};

u8 p2_izquierda2[64] =
{
	8,8,4,4,10,4,8,8,
	8,8,4,4,10,4,7,8,
    8,7,4,4,10,4,8,8,
    8,8,4,4,10,4,8,8,
    8,8,11,11,10,11,8,8,
    8,11,11,8,11,11,8,8,
    9,9,9,7,11,11,8,8,
    8,8,8,9,9,9,8,8,
  
};

u8 p_izquierda_suelo[64] =
{
	8,8,9,9,9,9,8,8,
	8,9,9,9,9,9,9,8,
	8,4,4,4,4,4,4,8,
	9,9,9,9,9,9,9,9,
	8,6,6,6,6,6,6,8,
	8,6,6,10,10,6,6,6,
	8,8,10,0,10,6,6,6,
	8,10,10,10,10,10,6,8,
	

};

//arriba
u8 p_arriba1[64] =
{
    2,3,9,9,9,9,3,2,
    3,9,9,9,9,9,9,2,
    2,4,4,4,4,4,4,3,
    9,9,9,9,9,9,9,9,
    6,6,6,6,6,6,6,6,
    6,6,6,6,6,6,6,6,
    6,6,6,6,6,6,6,6,
    3,6,6,6,6,6,6,2,
};

u8 p_arriba2[64] =
{
	8,8,9,9,9,9,8,8,
	8,9,9,9,9,9,9,8,
    8,4,4,4,4,4,4,8,
    9,9,9,9,9,9,9,9,
    6,6,6,6,6,6,6,6,
    6,6,6,6,6,6,6,6,
    6,6,6,6,6,6,6,6,
    8,6,6,6,6,6,6,8,
};


//piernas arriba - abajo

u8 p_caminar1[64] =
{
	10,4,4,4,4,4,4,10,
    10,4,4,4,4,4,4,10,
    10,4,4,4,4,4,4,10,
    10,4,4,4,4,4,4,10,
    10,11,11,11,11,11,11,10,
    8,11,11,7,8,11,11,8,
    8,11,11,8,8,9,9,8,
    8,9,9,8,8,8,8,8,
};


u8 p_caminar2[64] =
{
	10,4,4,4,4,4,4,10,
    10,4,4,4,4,4,4,10,
    10,4,4,4,4,4,4,10,
    10,4,4,4,4,4,4,10,
    10,11,11,11,11,11,11,10,
    8,11,11,7,8,11,11,8,
    8,9,9,8,8,11,11,8,
    8,8,8,8,9,9,8,
};
  


//cofre
u8 cofre1[64] =
{
    3,3,2,2,3,3,2,2,
    9,9,9,9,9,9,9,9,
    9,8,8,8,8,8,8,9,
    9,8,8,3,3,8,8,9,
    9,9,9,9,9,9,9,9,
    9,8,8,8,8,8,8,9,
    9,8,8,8,8,8,8,9,
    9,9,9,9,9,9,9,9,
};

u8 cofre2[64] =
{
    9,9,9,9,9,9,9,9,
    9,8,8,8,8,8,8,9,
    9,8,8,3,3,8,8,9,
    9,9,9,9,9,9,9,9,
    9,6,6,6,6,6,6,9,
    9,9,9,9,9,9,9,9,
    9,8,8,8,8,8,8,9,
    9,9,9,9,9,9,9,9,
};

//veneno

u8 veneno[64] =
{
	9,9,6,6,6,6,9,9,
	9,6,9,9,9,9,6,9,
    6,9,4,4,4,6,9,6,
    6,9,4,4,6,9,9,6,
    6,9,6,9,9,9,9,6,
    6,9,6,4,9,4,4,6,
    9,6,9,4,4,4,6,9,
    9,9,6,6,6,6,9,9,
  
};

//Humo

u8 humo_I1[64] =
{
    3,2,2,2,2,3,2,2,
    3,2,2,6,6,3,2,2,
    2,3,6,5,5,6,3,3,
    2,6,5,5,7,6,2,3,
    2,6,7,7,6,2,2,2,
    3,3,6,6,3,2,2,2,
    2,3,2,2,2,3,3,7,
    2,2,2,2,7,7,7,7,
};

u8 humo_D1[64] =
{
	3,2,2,2,2,3,2,2,
    3,2,2,2,3,3,2,2,
    2,3,3,2,2,2,3,3,
    2,2,3,2,2,2,2,3,
    3,6,6,6,6,8,3,3,
    6,5,5,5,5,6,8,3,
    5,5,5,5,5,5,6,2,
    5,5,5,5,5,5,6,3,
};

u8 humo_I2[64] =
{
	8,8,8,6,5,5,5,5,
	8,7,6,7,5,5,5,5,
    8,8,6,7,5,5,5,7,
    8,8,6,7,7,5,7,6,
    8,8,7,6,7,7,7,6,
    8,8,8,6,6,6,8,8,
    8,8,8,7,7,8,8,8,
    8,8,8,8,8,8,8,8,
  
};

u8 humo_D2[64] =
{
	5,5,5,5,5,6,8,8,
	5,5,5,5,5,7,6,8,
    6,5,5,5,5,7,7,6,
    7,5,5,5,5,5,5,6,
    7,7,5,5,5,7,7,6,
    6,7,7,5,5,7,6,8,
    8,6,7,7,7,7,6,8,
    8,8,6,6,6,6,8,8,
  
};

u8 humo2_I1[64] =
{
    3,2,2,2,2,3,2,2,
    3,2,2,2,3,3,2,2,
    2,3,3,2,2,2,3,3,
    2,2,3,2,2,2,2,3,
    2,2,2,2,3,2,2,2,
    3,3,2,3,3,2,2,6,
    2,3,2,2,2,3,3,6,
    2,2,2,2,2,3,2,6,
};

u8 humo2_D1[64] =
{
    3,2,2,2,2,3,2,2,
    3,2,2,2,3,3,2,2,
    2,3,3,2,2,2,3,3,
    2,2,3,2,2,2,2,3,
    6,6,2,2,3,2,2,2,
    5,5,6,3,3,2,2,2,
    5,5,7,6,2,3,3,2,
    5,5,7,6,2,3,2,2,
};

u8 humo2_I2[64] =
{
	8,8,8,8,6,6,6,5,
	8,7,8,6,5,5,5,5,
    8,8,6,7,5,5,7,7,
    8,8,6,7,5,5,7,6,
    8,8,7,6,6,6,6,8,
    8,8,8,8,8,8,8,8,
    8,8,8,7,7,8,8,8,
    8,8,8,8,8,8,8,8,
  
};

u8 humo2_D2[64] =
{
	6,6,6,8,8,8,8,8,
	6,7,8,8,8,8,8,8,
    8,8,8,8,6,6,7,8,
    8,8,7,6,5,7,6,8,
    8,8,6,7,7,7,6,8,
    8,8,8,6,6,6,8,8,
    8,8,8,7,7,8,8,8,
    8,8,8,8,8,8,8,8,
  
};

u16 mapData[768] =
{
	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,

	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0, 0,4,6,0,0,0,0,0,
	0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,  0,0,0,0,0,0,0,0, 0,5,7,0,0,0,0,0,

	1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,  1,1,1,1,1,1,1,1, 1,1,16,1,1,1,1,1,
	1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,  1,1,1,1,1,1,1,1, 1,1,16,1,1,1,1,1,
	1,1,1,1,1,16,16,16, 16,16,16,16,16,1,1,1,  1,1,1,1,1,1,1,1, 1,1,16,16,16,1,1,1,
    1,1,1,1,1,1,1,1, 1,1,1,1,16,1,1,1,  1,1,1,16,1,1,1,1, 1,1,1,1,16,1,1,1,

    1,1,1,1,1,1,1,1, 1,1,1,1,16,16,16,16,  1,1,1,16,1,1,1,34, 1,1,1,16,16,1,1,1,
    1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,16,  1,16,16,16,1,1,1,16, 1,1,1,16,1,1,1,1,
    1,1,16,16,16,1,1,1, 1,1,1,1,34,1,1,16,  16,16,1,16,1,1,1,16, 1,1,1,16,1,1,1,1,
    1,1,1,1,16,1,1,1, 1,1,1,1,16,16,16,16,  1,1,1,16,16,16,16,16, 1,1,1,16,1,1,1,1,

    1,1,1,1,16,1,1,1, 1,1,1,1,16,1,1,1,  1,1,1,16,1,1,1,1, 1,1,1,16,16,16,34,1,
    1,1,1,1,16,16,16,16, 16,16,1,1,16,1,1,1,  1,1,16,16,16,16,1,1, 1,1,1,16,1,1,1,1,
    1,1,1,1,1,1,1,1, 1,16,16,16,16,1,1,1,  1,1,16,1,1,16,1,16, 16,16,16,16,16,16,1,1,
    1,1,1,1,1,1,1,1, 1,1,1,1,16,1,1,1,  1,1,16,1,1,16,16,16, 1,1,1,1,1,16,1,1,

    1,1,1,1,1,1,1,1, 1,1,1,1,16,1,1,1,  1,1,16,1,1,1,1,1, 1,1,1,1,1,16,1,1,
    1,1,1,1,16,16,16,16, 1,1,1,1,16,1,1,1,  16,16,16,16,16,16,1,1, 1,1,1,1,1,34,1,1,
    1,16,16,16,16,1,1,16, 16,16,16,16,16,1,1,1,  1,1,1,1,1,16,1,1, 1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1,1,  1,1,1,1,1,16,16,16, 1,1,1,1,1,1,1,1,

};


	

//variables globales	
static u16* mapMemory;
int pos_mapMemory;
int pos_mapData;	

int estado;
int serpientes = 4;
int llave = 0;
int inicio = 0;
int victoria = 0;
int cant_veneno = 0;

//Funciones
void InicializarPartida();
void ConfigurarInterrupciones();
void int_timer0();
void int_timer1();
void int_timer2();
void int_timer3();
void Animacion_enemigos();
void Mover_personaje();
void Borrado_personaje();
void Animacion_personaje();
void Coger_veneno();
void Muerte(); 
void Animacion_cofre();
void Iniciar_mapa();

//mapa
int mfila;
int mcolumna;
int pos_mapMemory;
int pos_mapData;
	
//definimos las posiciones de las nubes
//Pequeñas
int fil1 = 3;
int col1 = 10;

int fil2 = 2;
int col2 = 30;

//nubes Grandes
int fil3 = 4;
int col3 = 25;

int fil4 = 0;
int col4 = 54;

//serpientea
int s_fil = 13;
int s_col = 0;

int s_fil2 = 20;
int s_col2 = 15;

int s_fil3 = 9;
int s_col3 = 18;

int s_fil4 = 22;
int s_col4 = 23;

//personaje
int p_fila = 22;
int p_columna = 1;
int animacion = 0;
int vidas = 3;
//cofre
int f_cofre = 9;
int c_cofre = 3;
bool cofre = false;

//enemigos
int t_enemigos = 0;

//
//muertes
int muerte = 0;
int t_muerte = 0;
int fila;
int columna;


void InicializarPartida()
{
	while(inicio==0)
	{
		p_fila = 22;
		p_columna = 1;
		llave = 0;
		serpientes = 4;
		cant_veneno = 0;
		vidas = 3;
		victoria = 0;
		Iniciar_mapa();
		REG_KEYCNT = 0x4001; //Desactivamos todas las teclas excepto la A
        irqDisable(IRQ_TIMER0);  
		irqDisable(IRQ_TIMER1);
		irqDisable(IRQ_TIMER2);
		irqDisable(IRQ_TIMER3);
		iprintf("\x1b[13;2HPulsa A para empezar");
        estado = 0;
        
        if (REG_KEYINPUT == 0x03FE) //En caso de que se pulse el botón A
		{  
            REG_KEYCNT = 0x40F0; //Activamos las demás teclas
            inicio = 1;
        } 
		
	}
	
	if(inicio==1)
	{
		consoleClear();
		//Imprimir nubes
		//Pequeñas
		pos_mapMemory = (fil1)*32+col1;
		mapMemory[pos_mapMemory] = 2;
			
		pos_mapMemory = (fil2)*32+col2;
		mapMemory[pos_mapMemory] = 2;
		
		//Grandes
		pos_mapMemory = (fil3)*32+col3;
		mapMemory[pos_mapMemory] = 3;
		
		pos_mapMemory = (fil4)*32+col4;
		mapMemory[pos_mapMemory] = 3;
		
		//serpiente
		pos_mapMemory = (s_fil)*32+s_col;
		mapMemory[pos_mapMemory] = 8;
		
		pos_mapMemory = (s_fil+1)*32+s_col;
		mapMemory[pos_mapMemory] = 9;
		
		pos_mapMemory = (s_fil)*32+(s_col+1);
		mapMemory[pos_mapMemory] = 10;
		
		pos_mapMemory = (s_fil+1)*32+(s_col+1);
		mapMemory[pos_mapMemory] = 11;
		
		//serpiente 2
		pos_mapMemory = (s_fil2)*32+s_col2;
		mapMemory[pos_mapMemory] = 8;
		
		pos_mapMemory = (s_fil2+1)*32+s_col2;
		mapMemory[pos_mapMemory] = 9;
		
		pos_mapMemory = (s_fil2)*32+(s_col2+1);
		mapMemory[pos_mapMemory] = 10;
		
		pos_mapMemory = (s_fil2+1)*32+(s_col2+1);
		mapMemory[pos_mapMemory] = 11;
		
		//serpiente3
		pos_mapMemory = (s_fil3)*32+s_col3;
		mapMemory[pos_mapMemory] = 8;
		
		pos_mapMemory = (s_fil3+1)*32+s_col3;
		mapMemory[pos_mapMemory] = 9;
		
		pos_mapMemory = (s_fil3)*32+(s_col3+1);
		mapMemory[pos_mapMemory] = 10;
		
		pos_mapMemory = (s_fil3+1)*32+(s_col3+1);
		mapMemory[pos_mapMemory] = 11;
		
		//serpiente4
		pos_mapMemory = (s_fil4)*32+s_col4;
		mapMemory[pos_mapMemory] = 8;
		
		pos_mapMemory = (s_fil4+1)*32+s_col4;
		mapMemory[pos_mapMemory] = 9;
		
		pos_mapMemory = (s_fil4)*32+(s_col4+1);
		mapMemory[pos_mapMemory] = 10;
		
		pos_mapMemory = (s_fil4+1)*32+(s_col4+1);
		mapMemory[pos_mapMemory] = 11;
		
		//cofre
		pos_mapMemory = (f_cofre+1)*32+(c_cofre+1);
		mapMemory[pos_mapMemory] = 17;
		
		//personaje
		pos_mapMemory = (p_fila)*32+p_columna;
		mapMemory[pos_mapMemory] = 20;
			
		pos_mapMemory = (p_fila-1)*32+p_columna;
		mapMemory[pos_mapMemory] = 19;
		
		
		
		//Imprimimos las estadisticas
		irqEnable(IRQ_TIMER0);
		irqEnable(IRQ_TIMER1);
		irqEnable(IRQ_TIMER2);
		
	}
	
	else if(inicio == 2) { 
	
		Iniciar_mapa();
		irqDisable(IRQ_TIMER0);  
		irqDisable(IRQ_TIMER1);
		irqDisable(IRQ_TIMER2);
		irqDisable(IRQ_TIMER3);
	}
	
	else if(inicio == 3)
	{
		Iniciar_mapa();
		irqDisable(IRQ_TIMER0);  
		irqDisable(IRQ_TIMER1);
		irqDisable(IRQ_TIMER2);
		irqDisable(IRQ_TIMER3);
	
	}
}

void ConfigurarInterrupciones()
{
	//Teclas
	irqSet(IRQ_KEYS,Mover_personaje);
	irqEnable(IRQ_KEYS); 
	//Temporizador nubes pequeñas
	irqDisable(IRQ_TIMER0);
	irqSet(IRQ_TIMER0,int_timer0);
	TIMER_DATA(0)=32764; 
	TIMER_CR(0) = TIMER_DIV_1024 | TIMER_ENABLE | TIMER_IRQ_REQ ;
	
	//Temporizador nubes grandes y enemigos
	irqDisable(IRQ_TIMER1);
	irqSet(IRQ_TIMER1,int_timer1);
	TIMER_DATA(1)=49152; 
	TIMER_CR(1) = TIMER_DIV_1024 | TIMER_ENABLE | TIMER_IRQ_REQ ;
	
	//Temporizador inicio
	irqDisable(IRQ_TIMER2);
	irqSet(IRQ_TIMER2,int_timer2);
	TIMER_DATA(2)=50000; 
	TIMER_CR(2) = TIMER_DIV_1024 | TIMER_ENABLE | TIMER_IRQ_REQ ;
	
	//Temporizador muertes
	irqEnable(IRQ_TIMER3);
	irqSet(IRQ_TIMER3,int_timer3);
	TIMER_DATA(3)=50000; 
	TIMER_CR(3) = TIMER_DIV_1024 | TIMER_ENABLE | TIMER_IRQ_REQ ;
	
	
}

void Iniciar_mapa(){
	pos_mapData = 0;
	for(mfila=0;mfila<24;mfila++)
	{
		for(mcolumna=0;mcolumna<32;mcolumna++)
		{
			pos_mapMemory            = mfila*32+mcolumna;
			mapMemory[pos_mapMemory] = mapData[pos_mapData];
			pos_mapData ++;
		}
	}
}


void int_timer0()
{
    //nube1
	
	pos_mapMemory = (fil1)*32+col1;
	mapMemory[pos_mapMemory] = 0;
	if(col1 < 31) { col1++;}
	else if (col1 == 31) { col1 = 0; }
	
	pos_mapMemory = (fil1)*32+col1;
	mapMemory[pos_mapMemory] = 2;
	
	//nube2
	pos_mapMemory = (fil2)*32+col2;
	mapMemory[pos_mapMemory] = 0;
	if(col2 < 31) { col2++;}
	else if (col2 == 31) { col2 = 0; }

	pos_mapMemory = (fil2)*32+col2;
	mapMemory[pos_mapMemory] = 2;
	

}

void int_timer1(){

	//nube3
	
	pos_mapMemory = (fil3)*32+col3;
	mapMemory[pos_mapMemory] = 0;
	if(col3 > 0) { col3--;}
	else if (col3 == 0) { col3 = 32; }

	pos_mapMemory = (fil3)*32+col3;
	mapMemory[pos_mapMemory] = 3;
	
	//nube4
	pos_mapMemory = (fil4)*32+col4;
	mapMemory[pos_mapMemory] = 0;
	if(col4 > 0) { col4--;}
	else if (col4 == 0) { col4 = 32; }

	pos_mapMemory = (fil4)*32+col4;
	mapMemory[pos_mapMemory] = 3;
}

void int_timer2(){
	if (t_enemigos == 2) { t_enemigos = 0 ; }
	Animacion_enemigos();
	t_enemigos++; 
}

void int_timer3(){
	
	if(t_muerte == 6)
	{	
		
		t_muerte = 0;
		irqDisable(IRQ_TIMER3);

	}
	else{ t_muerte++;}
	
	
	if (muerte==1)
	{
		if(t_muerte==1)
		{
			pos_mapMemory = (fila)*32+(columna);
			mapMemory[pos_mapMemory]=35;
				
			pos_mapMemory = (fila)*32+(columna+1);
			mapMemory[pos_mapMemory]=36;
				
			pos_mapMemory = (fila+1)*32+(columna);
			mapMemory[pos_mapMemory]=37;
				
			pos_mapMemory = (fila+1)*32+(columna+1);
			mapMemory[pos_mapMemory]=38;
			cant_veneno = 0;
			serpientes--;

				
		}
			
		if(t_muerte == 3)
		{
			pos_mapMemory = (fila)*32+(columna);
			mapMemory[pos_mapMemory]=39;
				
			pos_mapMemory = (fila)*32+(columna+1);
			mapMemory[pos_mapMemory]=40;
				
			pos_mapMemory = (fila+1)*32+(columna);
			mapMemory[pos_mapMemory]=41;
			
			pos_mapMemory = (fila+1)*32+(columna+1);
			mapMemory[pos_mapMemory]=42;				
		}
	}
	
	if(serpientes == 0) { cofre = true;}
	iprintf("\x1b[22;20H x%d Veneno", cant_veneno);
}
	
void Animacion_enemigos(){
	
	if(t_enemigos == 0)
	{
		//serpiente 1
		pos_mapMemory = (s_fil)*32+s_col;
		if((mapMemory[pos_mapMemory]!=35) && (mapMemory[pos_mapMemory]!=39))
		{
			mapMemory[pos_mapMemory] = 8;
			
			pos_mapMemory = (s_fil+1)*32+s_col;
			mapMemory[pos_mapMemory] = 9;
			
			pos_mapMemory = (s_fil)*32+(s_col+1);
			mapMemory[pos_mapMemory] = 10;
			
			pos_mapMemory = (s_fil+1)*32+(s_col+1);
			mapMemory[pos_mapMemory] = 11;
		}
		
		//serpiente 2
		pos_mapMemory = (s_fil2)*32+s_col2;
		if((mapMemory[pos_mapMemory]!=35) && (mapMemory[pos_mapMemory]!=39))
		{
			mapMemory[pos_mapMemory] = 8;
			
			pos_mapMemory = (s_fil2+1)*32+s_col2;
			mapMemory[pos_mapMemory] = 9;
			
			pos_mapMemory = (s_fil2)*32+(s_col2+1);
			mapMemory[pos_mapMemory] = 10;
			
			pos_mapMemory = (s_fil2+1)*32+(s_col2+1);
			mapMemory[pos_mapMemory] = 11;
		}
		
		//serpiente 3
		pos_mapMemory = (s_fil3)*32+s_col3;
		if((mapMemory[pos_mapMemory]!=35) && (mapMemory[pos_mapMemory]!=39))
		{
			mapMemory[pos_mapMemory] = 8;
			
			pos_mapMemory = (s_fil3+1)*32+s_col3;
			mapMemory[pos_mapMemory] = 9;
			
			pos_mapMemory = (s_fil3)*32+(s_col3+1);
			mapMemory[pos_mapMemory] = 10;
			
			pos_mapMemory = (s_fil3+1)*32+(s_col3+1);
			mapMemory[pos_mapMemory] = 11;
		}
		
		//serpiente4
		pos_mapMemory = (s_fil4)*32+s_col4; 
		if((mapMemory[pos_mapMemory]!=35) && (mapMemory[pos_mapMemory]!=39))
		{
			mapMemory[pos_mapMemory] = 8;
			
			pos_mapMemory = (s_fil4+1)*32+s_col4;
			mapMemory[pos_mapMemory] = 9;
			
			pos_mapMemory = (s_fil4)*32+(s_col4+1);
			mapMemory[pos_mapMemory] = 10;
			
			pos_mapMemory = (s_fil4+1)*32+(s_col4+1);
			mapMemory[pos_mapMemory] = 11;
		}
	}
	else if(t_enemigos == 1)
	{
		//serpiente 1
		pos_mapMemory = (s_fil)*32+s_col;
		if((mapMemory[pos_mapMemory]!=35) && (mapMemory[pos_mapMemory]!=39))
		{
			mapMemory[pos_mapMemory] = 12;
			
			pos_mapMemory = (s_fil+1)*32+s_col;
			mapMemory[pos_mapMemory] = 13;
			
			pos_mapMemory = (s_fil)*32+(s_col+1);
			mapMemory[pos_mapMemory] = 14;
			
			pos_mapMemory = (s_fil+1)*32+(s_col+1);
			mapMemory[pos_mapMemory] = 15;
		}
		
		//serpiente 2
		pos_mapMemory = (s_fil2)*32+s_col2;
		if((mapMemory[pos_mapMemory]!=35) && (mapMemory[pos_mapMemory]!=39))
		{
			mapMemory[pos_mapMemory] = 12;
			
			pos_mapMemory = (s_fil2+1)*32+s_col2;
			mapMemory[pos_mapMemory] = 13;
			
			pos_mapMemory = (s_fil2)*32+(s_col2+1);
			mapMemory[pos_mapMemory] = 14;
			
			pos_mapMemory = (s_fil2+1)*32+(s_col2+1);
			mapMemory[pos_mapMemory] = 15;
		}
		
		//serpiente 3
		pos_mapMemory = (s_fil3)*32+s_col3;
		if((mapMemory[pos_mapMemory]!=35) && (mapMemory[pos_mapMemory]!=39))
		{
			mapMemory[pos_mapMemory] = 12;
			
			pos_mapMemory = (s_fil3+1)*32+s_col3;
			mapMemory[pos_mapMemory] = 13;
			
			pos_mapMemory = (s_fil3)*32+(s_col3+1);
			mapMemory[pos_mapMemory] = 14;
			
			pos_mapMemory = (s_fil3+1)*32+(s_col3+1);
			mapMemory[pos_mapMemory] = 15;
		}
		
		//serpiente4
		pos_mapMemory = (s_fil4)*32+s_col4;
		if((mapMemory[pos_mapMemory]!=35) && (mapMemory[pos_mapMemory]!=39))
		{
			mapMemory[pos_mapMemory] = 12;
			
			pos_mapMemory = (s_fil4+1)*32+s_col4;
			mapMemory[pos_mapMemory] = 13;
			
			pos_mapMemory = (s_fil4)*32+(s_col4+1);
			mapMemory[pos_mapMemory] = 14;
			
			pos_mapMemory = (s_fil4+1)*32+(s_col4+1);
			mapMemory[pos_mapMemory] = 15;
		}
	}
} 

void Mover_personaje(){
	
	if(REG_KEYINPUT == 0x03DF)
	{
		estado = 2; //izquierda
	}
	
	if(REG_KEYINPUT == 0x03EF)
	{
		
		estado = 1; //Derecha
	}
	
	if (REG_KEYINPUT == 0x03BF) //Subir
	{
		estado = 3;
	}
	
	if (REG_KEYINPUT == 0x037F) //Bajar
	{
		estado=4;
	}
	
	Animacion_personaje();
	
}

void Animacion_personaje()
{
	if (estado == 1)
	{	
		pos_mapMemory = (p_fila)*32+(p_columna+1);
		
		if(mapMemory[pos_mapMemory]==34){ Coger_veneno(); }
		
		//En el caso de que haya una serpiente y tengamos veneno
		if(((mapMemory[pos_mapMemory]==13) || (mapMemory[pos_mapMemory]==9))) 
		{ 
			if(cant_veneno==1)
			{
				muerte = 1;
			}
			else { muerte = 2; }
			Muerte();
		}
		
		if(mapMemory[pos_mapMemory] == 16) 
		{
			p_columna+=1;
			Borrado_personaje();
			
			//movimiento del personaje derecha
			
			if (animacion == 0)
			{
				pos_mapMemory = (p_fila)*32+p_columna;
				mapMemory[pos_mapMemory] = 22;
				animacion = 1;
			}else {	
				pos_mapMemory = (p_fila)*32+p_columna;
				mapMemory[pos_mapMemory] = 23;	
				animacion = 0;
			}	
				
			pos_mapMemory = (p_fila-1)*32+p_columna;
			if((mapMemory[pos_mapMemory]==16) || (mapMemory[pos_mapMemory]==28))
			{
				mapMemory[pos_mapMemory] = 24;
			}else{
				mapMemory[pos_mapMemory] = 21;
			}	
		}
	}
	
	if (estado==2)
	{
		pos_mapMemory = (p_fila)*32+(p_columna-1);
		
		if(mapMemory[pos_mapMemory]==34){ Coger_veneno(); }
		
		if((mapMemory[pos_mapMemory]==17) && (cofre == true)){ Animacion_cofre(); }
		
		//En el caso de que haya una serpiente y tengamos veneno
		if(((mapMemory[pos_mapMemory]==15) || (mapMemory[pos_mapMemory]==11))) 
		{ 
			if(cant_veneno==1)
			{
				muerte = 1;
			}
			else { muerte = 2; }
			Muerte();
		}
		
		if(mapMemory[pos_mapMemory]== 16) 
		{
			p_columna-=1;
			Borrado_personaje();
			
			//movimiento del personaje izquierda
			
			if (animacion == 0)
			{
				pos_mapMemory = (p_fila)*32+p_columna;
				mapMemory[pos_mapMemory] = 26;
				animacion = 1;
				
			}else{
				pos_mapMemory = (p_fila)*32+p_columna;
				mapMemory[pos_mapMemory] = 27;
				animacion = 0;
				
			}	
			pos_mapMemory = (p_fila-1)*32+p_columna;
			if((mapMemory[pos_mapMemory]==16) || (mapMemory[pos_mapMemory]==24) || (mapMemory[pos_mapMemory]==29)) 
			{
				mapMemory[pos_mapMemory] = 28;
			}else{
				mapMemory[pos_mapMemory] = 25;
			}
			
		}
		
		
	}
	
	if (estado == 0)
	{
		
		pos_mapMemory = (p_fila)*32+p_columna;
		mapMemory[pos_mapMemory] = 20;
		
		pos_mapMemory = (p_fila-1)*32+p_columna;
		mapMemory[pos_mapMemory] = 19;
		
	}
	
	if (estado == 3)
	{
		pos_mapMemory = (p_fila-2)*32+(p_columna);
		
		//En el caso de que haya una serpiente y tengamos veneno
		if(((mapMemory[pos_mapMemory]==15) || (mapMemory[pos_mapMemory]==11))) 
		{ 
			if(cant_veneno==1)
			{
				muerte = 1;
			}
			else { muerte = 2; }
			Muerte();
		}
		
		
		//En el caso de que haya un bote de veneno
		if(mapMemory[pos_mapMemory] ==34){ Coger_veneno(); }
		if(mapMemory[pos_mapMemory] ==7){ victoria = 1; }
		
		
		pos_mapMemory = (p_fila-1)*32+(p_columna);
		if((mapMemory[pos_mapMemory]!=1) && (mapMemory[pos_mapMemory]!=19) && (mapMemory[pos_mapMemory]!=21) && (mapMemory[pos_mapMemory]!=25) && (mapMemory[pos_mapMemory]!=30) && (mapMemory[pos_mapMemory]!=42))
		{
			pos_mapMemory = (p_fila-2)*32+(p_columna);
			if((mapMemory[pos_mapMemory]!=11) && (mapMemory[pos_mapMemory]!=15))
			{
				p_fila-=1;
				Borrado_personaje();
				
				//movimiento del personaje arriba
				
				if (animacion == 0)
				{
					pos_mapMemory = (p_fila)*32+p_columna;
					mapMemory[pos_mapMemory] = 32 ;
					animacion = 1;
					
				}else{
					pos_mapMemory = (p_fila)*32+p_columna;
					mapMemory[pos_mapMemory] = 33;
					animacion = 0;
					
				}	
				pos_mapMemory = (p_fila-1)*32+p_columna;
				if((mapMemory[pos_mapMemory]==16) || (mapMemory[pos_mapMemory]==24) || (mapMemory[pos_mapMemory]==29) || (mapMemory[pos_mapMemory]==31))
				{
					mapMemory[pos_mapMemory] = 31;
				}else{
					mapMemory[pos_mapMemory] = 30;
				}
			}
		}
	}
	if (estado == 4)
	{
		pos_mapMemory = (p_fila+1)*32+(p_columna); //nos situamos en los pies del personaje
		
		if(mapMemory[pos_mapMemory]==34){ Coger_veneno(); }
		
		//En el caso de que haya una serpiente y tengamos veneno
		if(((mapMemory[pos_mapMemory]==13) || (mapMemory[pos_mapMemory]==15) || (mapMemory[pos_mapMemory]==9) || (mapMemory[pos_mapMemory]==11))) 
		{ 
			if(cant_veneno==1)
			{
				muerte = 1;
			}
			else { muerte = 2; }
			Muerte();
		}
		
		
		if(mapMemory[pos_mapMemory]== 16) // Si hay suelo
		{
			p_fila+=1;
			Borrado_personaje();
			
			//movimiento del personaje abajo
			
			if (animacion == 0)
			{
				pos_mapMemory = (p_fila)*32+p_columna; //primera animacion de los pies
				mapMemory[pos_mapMemory] = 32 ;
				animacion = 1;
				
			}else{
				pos_mapMemory = (p_fila)*32+p_columna; //segunda animacion de los pies
				mapMemory[pos_mapMemory] = 33;
				animacion = 0;
				
			}	
			pos_mapMemory = (p_fila-1)*32+p_columna; //cabeza del personaje
			if((mapMemory[pos_mapMemory]==16) || (mapMemory[pos_mapMemory]==24) || (mapMemory[pos_mapMemory]==28))
			{
				mapMemory[pos_mapMemory] = 29;
			}else{
				mapMemory[pos_mapMemory] = 19;
			}
		}
	}
}

void Borrado_personaje()
{
	if(estado==1) //borrado si el personaje va a la derecha
	{
		pos_mapMemory = (p_fila)*32+(p_columna-1);
		mapMemory[pos_mapMemory] = 16;
		
		pos_mapMemory = (p_fila-1)*32+(p_columna-1);
		if((mapMemory[pos_mapMemory] == 21) || (mapMemory[pos_mapMemory] == 25) || (mapMemory[pos_mapMemory] == 19) || (mapMemory[pos_mapMemory] == 30))
		{ 
			mapMemory[pos_mapMemory] = 1;
		}else{ 
			mapMemory[pos_mapMemory] = 16; 
		}
		
	}
	if(estado == 2) //borrado si el personaje va a la izquierda
	{
		pos_mapMemory = (p_fila)*32+(p_columna+1);
		mapMemory[pos_mapMemory] = 16;
		
		pos_mapMemory = (p_fila-1)*32+(p_columna+1);
		if((mapMemory[pos_mapMemory] == 25) || (mapMemory[pos_mapMemory] == 21) || (mapMemory[pos_mapMemory] == 19) || (mapMemory[pos_mapMemory] == 30))
		{ 
			mapMemory[pos_mapMemory] = 1;
		}else{ 
			mapMemory[pos_mapMemory] = 16; 
		}
	}
	
	
	if(estado == 3) //borrado si el personaje va  arriba
	{
		pos_mapMemory = (p_fila+1)*32+(p_columna);
		mapMemory[pos_mapMemory] = 16;
		
		
		pos_mapMemory = (p_fila+1)*32+(p_columna);
		if((mapMemory[pos_mapMemory] == 25) || (mapMemory[pos_mapMemory] == 21)  || (mapMemory[pos_mapMemory] == 19) || (mapMemory[pos_mapMemory] == 30))
		{ 
			mapMemory[pos_mapMemory] = 1;
		}else{ 
			mapMemory[pos_mapMemory] = 16; 
		}
	}
	
	if(estado == 4) //borrado si el personaje va abajo
	{
		
		pos_mapMemory = (p_fila-1)*32+(p_columna);
		mapMemory[pos_mapMemory] = 16;
		
		pos_mapMemory = (p_fila-2)*32+(p_columna);
		if((mapMemory[pos_mapMemory] == 25) || (mapMemory[pos_mapMemory] == 21)  || (mapMemory[pos_mapMemory] == 19) || (mapMemory[pos_mapMemory] == 30))
		{ 
			mapMemory[pos_mapMemory] = 1;
		}else{ 
			mapMemory[pos_mapMemory] = 16; 
		}
	}
	
}

void Animacion_cofre()
{
	mapMemory[pos_mapMemory]=18;
	llave = 1;
}

void Coger_veneno()
{
	if(cant_veneno==1)
	{
		iprintf("\x1b[17;5H ¡Ya tienes un bote!");
	}
	else //recoger veneno
	{
		cant_veneno = 1;
		mapMemory[pos_mapMemory]=1;
	}
}

void Muerte()
{
	
	
	if(muerte==1)
	{
		if(estado==1){
			
			fila = s_fil4;
			columna = s_col4;
				
		}
		
		if(estado==2)
		{
			if(p_fila==14)
			{
				fila = s_fil;
				columna = s_col;
			}
			if(p_fila==21)
			{
		
				fila = s_fil2;
				columna = s_col2;
			}
		}
		
		
		if(estado==3)
		{
			fila = s_fil3;
			columna = s_col3;
		}
		
	
	}	
	if(muerte==2){ vidas--; }
	
	if(serpientes == 0){
			
		iprintf("\x1b[9;10H ¡Cofre desbloqueado!");
			
	}
	
	if(vidas>0) {irqEnable(IRQ_TIMER3);}
}

int main( void )
{
	
	
	REG_POWERCNT = POWER_ALL_2D;
	REG_DISPCNT  = MODE_0_2D   | DISPLAY_BG0_ACTIVE ;
	VRAM_A_CR    = VRAM_ENABLE | VRAM_A_MAIN_BG   ;
	BGCTRL [0]   = BG_32x32    | BG_COLOR_256 | BG_MAP_BASE(0) | BG_TILE_BASE(1);
	
	BG_PALETTE[0]=RGB15(0,31,31); // Azul cielo
	BG_PALETTE[1]=RGB15(31,31,31); // Blanco
	BG_PALETTE[2]=RGB15(0, 23, 20); // verde oscuro
	BG_PALETTE[3]=RGB15( 0,31, 0); // verde claro
	BG_PALETTE[4]=RGB15( 28, 0, 0); // rojo
	BG_PALETTE[5]=RGB15( 28, 28, 28); // gris claro
	BG_PALETTE[6]=RGB15( 0, 0, 0); // Negro
	BG_PALETTE[7]=RGB15( 24, 24, 24); // gris
	BG_PALETTE[8]=RGB15(17, 9, 4); // MARRON
	BG_PALETTE[9]=RGB15(31, 31, 0); // amarillo
	BG_PALETTE[10]=RGB15(30, 25, 22); // rosa
	BG_PALETTE[11]=RGB15(0, 0, 31); // azul oscuro
	

	
	
	static u8*  tileMemory = (u8*)  BG_TILE_RAM(1);
	mapMemory  = (u16*) BG_MAP_RAM(0); 
	
	dmaCopy(cielo,          tileMemory,  sizeof(cielo)); //0
	dmaCopy(cesped, tileMemory + 64, 		 sizeof(cesped)); //1
	dmaCopy(nube_pequeña,     tileMemory + 128 , sizeof(nube_pequeña)); //2
	dmaCopy(nube_grande,     tileMemory + 192 ,      sizeof(nube_grande)); //3
	
	//casa
	dmaCopy(casa_I1,          tileMemory + 256 ,  sizeof(casa_I1)); //4
	dmaCopy(casa_I2, tileMemory + 320, 		 sizeof(casa_I2)); //5
	dmaCopy(casa_D1,     tileMemory + 384 , sizeof(casa_D1)); //6
	dmaCopy(casa_D2,     tileMemory + 448 ,      sizeof(casa_D2)); //7
	
	//serpiente
	//1 animacion
	dmaCopy(serpiente_I1,     tileMemory + 512 , sizeof(serpiente_I1)); //8
	dmaCopy(serpiente_I2,     tileMemory + 576 ,      sizeof(serpiente_I2)); //9
	dmaCopy(serpiente_D1,     tileMemory + 640 , sizeof(serpiente_D1)); //10
	dmaCopy(serpiente_D2,     tileMemory + 704 ,      sizeof(serpiente_D2)); //11
	
	//2 animacion
	dmaCopy(serpiente2_I1,     tileMemory + 768 , sizeof(serpiente2_I1)); //12
	dmaCopy(serpiente2_I2,     tileMemory + 832 ,      sizeof(serpiente2_I2)); //13
	dmaCopy(serpiente2_D1,     tileMemory + 896 , sizeof(serpiente2_D1)); //14
	dmaCopy(serpiente2_D2,     tileMemory + 960 ,      sizeof(serpiente2_D2)); //15
	
	//suelo
	dmaCopy(suelo,     tileMemory + 1024 ,      sizeof(suelo)); //16
	dmaCopy(cofre1,     tileMemory + 1088 ,      sizeof(cofre1)); //17
	dmaCopy(cofre2,     tileMemory + 1152 ,      sizeof(cofre2)); //18

	//personaje
	//frente
	dmaCopy(p_frente1,     tileMemory + 1216 ,      sizeof(p_frente1)); //19
	dmaCopy(p_frente2,     tileMemory + 1280 ,      sizeof(p_frente2)); //20
	
	//derecha
	dmaCopy(p_derecha1,     tileMemory + 1344 ,      sizeof(p_derecha1)); //21
	dmaCopy(p_derecha2,     tileMemory + 1408 ,      sizeof(p_derecha2)); //22
	dmaCopy(p2_derecha2,     tileMemory + 1472 ,      sizeof(p2_derecha2)); //23
	dmaCopy(p_derecha_suelo,     tileMemory + 1536 ,      sizeof(p_derecha_suelo)); //24
	
	//izquierda
	dmaCopy(p_izquierda1,     tileMemory + 1600 ,      sizeof(p_izquierda1)); //25
	dmaCopy(p_izquierda2,     tileMemory + 1664 ,      sizeof(p_izquierda2)); //26
	dmaCopy(p2_izquierda2,     tileMemory + 1728 ,      sizeof(p2_izquierda2)); //27
	dmaCopy(p_izquierda_suelo,     tileMemory + 1792 ,     sizeof(p_izquierda_suelo)); //28
	
	//frente suelo camino
	
	dmaCopy(p2_frente2,     tileMemory + 1856 ,     sizeof(p2_frente2)); //29
	
	//cabeza arriba
	dmaCopy(p_arriba1,     tileMemory + 1920 ,     sizeof(p_arriba1)); //30
	dmaCopy(p_arriba2,     tileMemory + 1984 ,     sizeof(p_arriba2)); //31
	
	dmaCopy(p_caminar1,     tileMemory + 2048 ,     sizeof(p_caminar1)); //32
	dmaCopy(p_caminar2,     tileMemory + 2112 ,     sizeof(p_caminar2)); //33
	
	dmaCopy(veneno,			tileMemory + 2176 ,     sizeof(veneno)); //34
	
	//humo animacion 1
	dmaCopy(humo_I1,			tileMemory + 2240 ,     sizeof(humo_I1)); //35
	dmaCopy(humo_D1,			tileMemory + 2304 ,     sizeof(humo_D1)); //36
	dmaCopy(humo_I2,			tileMemory + 2368 ,     sizeof(humo_I2)); //37
	dmaCopy(humo_D2,			tileMemory + 2432 ,     sizeof(humo_D2)); //38

	//humo animacion 2
	dmaCopy(humo2_I1,			tileMemory + 2496 ,     sizeof(humo2_I1)); //39
	dmaCopy(humo2_D1,			tileMemory + 2560 ,     sizeof(humo2_D1)); //40
	dmaCopy(humo2_I2,			tileMemory + 2624 ,     sizeof(humo2_I2)); //41
	dmaCopy(humo2_D2,			tileMemory + 2688 ,     sizeof(humo2_D2)); //42
	


	
	
	
	Iniciar_mapa();
	ConfigurarInterrupciones();
	consoleDemoInit();
	InicializarPartida();

	
	while(1)
	{
		if (victoria == 1) 
		{
			inicio = 2;	
		}
		if(vidas == 0){
			inicio = 3;
		}
		
		
		if(inicio==1)
		{
			iprintf("\x1b[3;2HTu granja ha sido invadida");
			iprintf("\x1b[4;3HDeshazte de las serpientes");
			iprintf("\x1b[5;4Hpara conseguir la llave");
			iprintf("\x1b[6;10Hde la casa");
			
			iprintf("\x1b[13;2H                                                           ");
			iprintf("\x1b[20;2H Serpientes: %d", serpientes);
			iprintf("\x1b[20;20H %d vidas", vidas);
			iprintf("\x1b[22;20H x%d Veneno", cant_veneno);
			if (llave == 1) { iprintf("\x1b[21;20H x%d Llave", llave); }
			
		}
		
		if(inicio == 2) {
			//borrado
			iprintf("\x1b[3;2H                                    ");
			iprintf("\x1b[4;3H                                    ");
			iprintf("\x1b[5;4H                                    ");
			iprintf("\x1b[6;10Hde la casa");
			
			iprintf("\x1b[13;2H                                                           ");
			iprintf("\x1b[20;2H Serpientes: %d", serpientes);
			iprintf("\x1b[20;20H %d vidas", vidas);
			iprintf("\x1b[22;20H x%d Veneno", cant_veneno);
			
			
			
			
			
			
			iprintf("\x1b[10;7H¡¡HAS GANADO");
			iprintf("\x1b[11;1HPulsa A para reiniciar el juego");
			
			REG_KEYCNT = 0x4001; //Desactivamos todas las teclas excepto la A
			if (REG_KEYINPUT == 0x03FE) //En caso de que se pulse el botón A
			{  
				REG_KEYCNT = 0x40F0; //Activamos las demás teclas
				inicio = 0;
				InicializarPartida();
			} 
			
		}
		
		if(inicio == 3)
		{
			//borrado
			consoleClear();
			

			iprintf("\x1b[2;7H ¡Has perdido!");
			iprintf("\x1b[12;7HNo te quedan vidas");
			iprintf("\x1b[20;2HPulsa A para reiniciar");
			iprintf("\x1b[21;8H el juego");
			
			REG_KEYCNT = 0x4001; //Desactivamos todas las teclas excepto la A
			if (REG_KEYINPUT == 0x03FE) //En caso de que se pulse el botón A
			{  
				REG_KEYCNT = 0x40F0; //Activamos las demás teclas
				inicio = 0;
				InicializarPartida();
			} 
		}
		swiWaitForVBlank();
	}
}
